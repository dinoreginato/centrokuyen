import { useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { Calendar, Clock, Stethoscope, User } from 'lucide-react'
import { toast } from 'sonner'
import { format, parseISO } from 'date-fns'
import { es } from 'date-fns/locale'
import { useAuth } from '@/contexts/AuthContext'
import { useSucursal } from '@/contexts/SucursalContext'
import { Atencion, Profesional, ProfesionalDisponibilidad } from '@/types/database'
import { atencionesService, profesionalDisponibilidadService, profesionalesService } from '@/utils/supabase'
import { hasPermission } from '@/utils/permissions'
import PageLoader from '@/components/ui/PageLoader'
import EmptyState from '@/components/ui/EmptyState'

const START_HOUR = 8
const END_HOUR = 21
const SESSION_MINUTES = 60

const timeToMinutes = (time: string) => {
  const raw = time?.substring(0, 5) || '00:00'
  const [hh, mm] = raw.split(':')
  return (parseInt(hh || '0', 10) * 60) + parseInt(mm || '0', 10)
}

const Disponibilidad = () => {
  const { user } = useAuth()
  const { currentCentro, currentSucursal } = useSucursal()
  const canSelectAnyProfessional = hasPermission(user, 'selectAnyProfessional')

  const [profesionales, setProfesionales] = useState<Profesional[]>([])
  const [loadingProfesionales, setLoadingProfesionales] = useState(true)

  const [selectedProfesionalId, setSelectedProfesionalId] = useState('')
  const [selectedDate, setSelectedDate] = useState(format(new Date(), 'yyyy-MM-dd'))

  const [atenciones, setAtenciones] = useState<Atencion[]>([])
  const [disponibilidad, setDisponibilidad] = useState<ProfesionalDisponibilidad[]>([])
  const [loadingAgenda, setLoadingAgenda] = useState(false)

  useEffect(() => {
    loadProfesionales()
    setAtenciones([])
    setDisponibilidad([])
  }, [currentCentro, currentSucursal])

  useEffect(() => {
    if (!selectedProfesionalId || !selectedDate) return
    if (!currentSucursal) return
    loadAgendaData()
  }, [selectedProfesionalId, selectedDate, currentCentro, currentSucursal])

  const loadProfesionales = async () => {
    try {
      setLoadingProfesionales(true)
      const data = await profesionalesService.getAll(currentSucursal?.id, currentCentro?.id)
      const filtered = (user?.rol === 'profesional' && user.profesional_id)
        ? data.filter(p => p.id === user.profesional_id)
        : data

      setProfesionales(filtered)

      if (user?.rol === 'profesional' && user.profesional_id) {
        setSelectedProfesionalId(user.profesional_id)
      } else if (!selectedProfesionalId && filtered.length > 0) {
        setSelectedProfesionalId(filtered[0].id)
      }
    } catch (error) {
      toast.error('Error al cargar profesionales')
      console.error('Error loading profesionales:', error)
    } finally {
      setLoadingProfesionales(false)
    }
  }

  const loadAgendaData = async () => {
    try {
      setLoadingAgenda(true)
      const diaSemana = parseISO(selectedDate).getDay()
      const [atencionesData, disponibilidadData] = await Promise.all([
        atencionesService.getByProfesionalAndDateRange(
          selectedProfesionalId,
          selectedDate,
          selectedDate,
          currentSucursal?.id,
          currentCentro?.id
        ),
        profesionalDisponibilidadService.getByProfesional(
          selectedProfesionalId,
          currentSucursal?.id,
          diaSemana
        )
      ])

      setAtenciones(atencionesData)
      setDisponibilidad(disponibilidadData)
    } catch (error) {
      toast.error('Error al cargar disponibilidad')
      console.error('Error loading disponibilidad:', error)
    } finally {
      setLoadingAgenda(false)
    }
  }

  const slots = useMemo(() => {
    const result: string[] = []
    for (let h = START_HOUR; h <= END_HOUR; h++) {
      result.push(`${h.toString().padStart(2, '0')}:00`)
    }
    return result
  }, [])

  const atencionesDelDia = useMemo(() => {
    return atenciones.filter(a => a.fecha === selectedDate)
  }, [atenciones, selectedDate])

  const disponibilidadDelDia = useMemo(() => {
    return disponibilidad
      .map((item) => ({
        ...item,
        inicioMinutos: timeToMinutes(item.hora_inicio),
        finMinutos: timeToMinutes(item.hora_fin)
      }))
      .sort((a, b) => a.inicioMinutos - b.inicioMinutos)
  }, [disponibilidad])

  const slotRows = useMemo(() => {
    return slots.map((slot) => {
      const slotStart = timeToMinutes(slot)
      const slotEnd = slotStart + SESSION_MINUTES

      const ocupada = atencionesDelDia.find(a => {
        const start = timeToMinutes(a.hora)
        const end = start + SESSION_MINUTES
        return start < slotEnd && end > slotStart
      })

      const dentroDeHorario = disponibilidadDelDia.some(rango =>
        slotStart >= rango.inicioMinutos && slotEnd <= rango.finMinutos
      )

      const estado = ocupada
        ? 'ocupado'
        : disponibilidadDelDia.length === 0
        ? 'sin_horario'
        : dentroDeHorario
        ? 'disponible'
        : 'fuera_de_horario'

      return { slot, ocupada, estado }
    })
  }, [slots, atencionesDelDia, disponibilidadDelDia])

  if (loadingProfesionales) {
    return <PageLoader label="Cargando disponibilidad..." />
  }

  const selectedProfesional = profesionales.find(p => p.id === selectedProfesionalId) || null
  const dateLabel = selectedDate ? format(parseISO(selectedDate), 'EEEE dd/MM/yyyy', { locale: es }) : ''
  const disponibilidadLabel = disponibilidadDelDia.length > 0
    ? disponibilidadDelDia
        .map((rango) => `${rango.hora_inicio.substring(0, 5)} - ${rango.hora_fin.substring(0, 5)}`)
        .join(' · ')
    : 'Sin horario configurado para este día'

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-800">Disponibilidad</h1>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Profesional</label>
            <div className="relative">
              <Stethoscope className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <select
                value={selectedProfesionalId}
                onChange={(e) => setSelectedProfesionalId(e.target.value)}
                className="w-full pl-10 px-3 py-2 border border-gray-300 rounded-md focus:ring-medical-blue focus:border-medical-blue disabled:bg-gray-100 disabled:cursor-not-allowed"
                disabled={!canSelectAnyProfessional}
              >
                {profesionales.map(p => (
                  <option key={p.id} value={p.id}>
                    {p.nombre} - {p.especialidad}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Fecha</label>
            <div className="relative">
              <Calendar className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="w-full pl-10 px-3 py-2 border border-gray-300 rounded-md focus:ring-medical-blue focus:border-medical-blue"
              />
            </div>
          </div>
        </div>

        <div className="mt-4 text-sm text-gray-600">
          {selectedProfesional ? (
            <div className="space-y-1">
              <div>
                <span className="font-medium">{selectedProfesional.nombre}</span>
                {' · '}
                <span className="capitalize">{dateLabel}</span>
              </div>
              <div>
                Horario configurado: <span className="font-medium">{disponibilidadLabel}</span>
              </div>
            </div>
          ) : (
            <span>Seleccione un profesional</span>
          )}
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6">
        {loadingAgenda ? (
          <PageLoader compact label="Calculando bloques del día..." />
        ) : slotRows.length === 0 ? (
          <EmptyState
            icon={Clock}
            title="Sin bloques para mostrar"
            description="No fue posible construir los bloques de horario para la fecha seleccionada."
          />
        ) : (
          <>
            <div className="space-y-3 md:hidden">
              {slotRows.map(({ slot, ocupada, estado }) => (
                <div key={slot} className="rounded-lg border border-gray-200 p-4 shadow-sm">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-gray-400" />
                      <span className="font-semibold text-gray-900">{slot}</span>
                    </div>
                    {estado === 'ocupado' ? (
                      <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-800">
                        Ocupado
                      </span>
                    ) : estado === 'disponible' ? (
                      <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                        Disponible
                      </span>
                    ) : (
                      <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-gray-100 text-gray-700">
                        {estado === 'sin_horario' ? 'Sin horario' : 'Fuera de horario'}
                      </span>
                    )}
                  </div>

                  <div className="mt-3">
                    {estado === 'ocupado' && ocupada ? (
                      <div className="flex items-start gap-2 text-sm text-gray-700">
                        <User className="h-4 w-4 text-gray-400 mt-0.5" />
                        <div>
                          <div className="font-medium">{ocupada.paciente?.nombre || 'Bloque sin paciente'}</div>
                          <div className="text-xs text-gray-500">
                            {ocupada.tipos_atencion?.nombre || ocupada.tipo_atencion || '-'}
                          </div>
                        </div>
                      </div>
                    ) : estado === 'disponible' ? (
                      <p className="text-sm text-gray-500">Horario libre dentro de la jornada configurada.</p>
                    ) : estado === 'sin_horario' ? (
                      <p className="text-sm text-gray-500">No hay un horario laboral configurado para este día.</p>
                    ) : (
                      <p className="text-sm text-gray-500">Este bloque queda fuera del horario laboral del profesional.</p>
                    )}
                  </div>

                  <div className="mt-4 flex justify-end border-t border-gray-100 pt-3">
                    {estado === 'ocupado' && ocupada ? (
                      <Link
                        to={`/agenda/${ocupada.id}`}
                        className="text-medical-blue hover:text-blue-700 font-medium text-sm"
                      >
                        Ver / editar
                      </Link>
                    ) : estado === 'disponible' ? (
                      <Link
                        to={`/agenda/nueva?profesional_id=${encodeURIComponent(selectedProfesionalId)}&fecha=${encodeURIComponent(selectedDate)}&hora=${encodeURIComponent(slot)}`}
                        className="inline-flex items-center px-3 py-1.5 border border-medical-blue text-medical-blue rounded-md hover:bg-medical-blue hover:text-white transition-colors text-sm"
                      >
                        Agendar
                      </Link>
                    ) : (
                      <span className="text-sm font-medium text-gray-400">No agendable</span>
                    )}
                  </div>
                </div>
              ))}
            </div>

            <div className="hidden overflow-x-auto md:block">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Hora</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Estado</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Paciente</th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Acciones</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {slotRows.map(({ slot, ocupada, estado }) => (
                  <tr key={slot} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4 text-gray-400" />
                        <span>{slot}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm">
                      {estado === 'ocupado' ? (
                        <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-800">
                          Ocupado
                        </span>
                      ) : estado === 'disponible' ? (
                        <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                          Disponible
                        </span>
                      ) : (
                        <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-gray-100 text-gray-700">
                          {estado === 'sin_horario' ? 'Sin horario' : 'Fuera de horario'}
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                      {estado === 'ocupado' && ocupada ? (
                        <div className="flex items-center gap-2">
                          <User className="h-4 w-4 text-gray-400" />
                          <div>
                            <div className="font-medium">{ocupada.paciente?.nombre || '-'}</div>
                            <div className="text-xs text-gray-500">
                              {ocupada.tipos_atencion?.nombre || '-'}
                            </div>
                          </div>
                        </div>
                      ) : estado === 'disponible' ? (
                        <span className="text-gray-500">Libre dentro del horario</span>
                      ) : estado === 'sin_horario' ? (
                        <span className="text-gray-400">Sin horario configurado</span>
                      ) : (
                        <span className="text-gray-400">Fuera de horario</span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-right">
                      {estado === 'ocupado' && ocupada ? (
                        <Link
                          to={`/agenda/${ocupada.id}`}
                          className="text-medical-blue hover:text-blue-700 font-medium"
                        >
                          Ver / editar
                        </Link>
                      ) : estado === 'disponible' ? (
                        <Link
                          to={`/agenda/nueva?profesional_id=${encodeURIComponent(selectedProfesionalId)}&fecha=${encodeURIComponent(selectedDate)}&hora=${encodeURIComponent(slot)}`}
                          className="inline-flex items-center px-3 py-1.5 border border-medical-blue text-medical-blue rounded-md hover:bg-medical-blue hover:text-white transition-colors"
                        >
                          Agendar
                        </Link>
                      ) : (
                        <span className="text-gray-400">No agendable</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          </>
        )}
      </div>
    </div>
  )
}

export default Disponibilidad
